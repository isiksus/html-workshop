
const rock = document.getElementById("rock");

document.addEventListener("click", () => {
  if (!rock) return;

  rock.classList.remove("fly");
  void rock.offsetWidth;
  rock.classList.add("fly");
});